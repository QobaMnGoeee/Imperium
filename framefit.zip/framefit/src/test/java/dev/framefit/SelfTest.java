package dev.framefit;

import dev.framefit.frame.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/** Dependency-free checks for the pure geometry core. Usage: SelfTest <oneparttextbox.png> [frames dir] */
public final class SelfTest {
    static int failures = 0, checks = 0;

    static void check(boolean ok, String msg) {
        checks++;
        if (!ok) { failures++; System.out.println("FAIL: " + msg); }
    }

    static void roundTrip(FramePixels p, String name) {
        List<Rect> rects = Mesher.mesh(p);
        check(Arrays.equals(Mesher.raster(rects, p.width, p.height), p.copyRaw()), "round trip " + name);
    }

    public static void main(String[] args) throws Exception {
        // 1. Real asset
        FrameLoader.Loaded loaded = FrameLoader.load(Path.of(args[0]));
        FramePixels src = loaded.pixels();
        check(src.width == 30 && src.height == 142, "asset size 30x142, got " + src.width + "x" + src.height);
        check(loaded.inferredScale() == 1, "asset is not upscaled");
        check(src.paletteSize() == 10, "asset palette 10 opaque colours, got " + src.paletteSize());
        check(!src.hasPartialAlpha(), "asset has no partial alpha");
        roundTrip(src, "asset");
        int baseRects = Mesher.mesh(src).size();
        check(baseRects == 39, "asset meshes to 39 rects, got " + baseRects);

        // 2. Three-slice on the asset
        ThreeSlice s = ThreeSlice.detect(src);
        check(s.stretchStart == 57 && s.stretchEnd == 86, "stretch band rows 57..85, got " + s.stretchStart + ".." + (s.stretchEnd - 1));
        check(s.minHeight() == 114, "min height 114, got " + s.minHeight());
        for (int target : new int[]{1, 100, 113, 114, 115, 142, 143, 200, 300, 1000}) {
            FramePixels r = s.resize(target);
            int th = Math.max(target, 114);
            check(r.height == th, "resize height for target " + target);
            boolean topOk = true, botOk = true;
            for (int y = 0; y < s.topHeight(); y++)
                for (int x = 0; x < src.width; x++) topOk &= r.get(x, y) == src.get(x, y);
            for (int y = 0; y < s.bottomHeight(); y++)
                for (int x = 0; x < src.width; x++)
                    botOk &= r.get(x, th - 1 - y) == src.get(x, src.height - 1 - y);
            check(topOk, "top cap intact at " + target);
            check(botOk, "bottom cap intact at " + target);
            List<Rect> m = s.meshFor(target);
            check(m.size() == baseRects, "rect count constant (" + m.size() + ") at target " + target);
            check(Arrays.equals(Mesher.raster(m, r.width, r.height), r.copyRaw()), "mesh round trip at target " + target);
        }
        check(Arrays.equals(s.resize(142).copyRaw(), src.copyRaw()), "resize to original height is identity");

        // 3. Random images and edge cases
        Random rnd = new Random(42);
        int[] palette = {0, 0xFFFF0000, 0xFF00FF00, 0xFF0000FF};
        for (int i = 0; i < 200; i++) {
            int w = 1 + rnd.nextInt(12), h = 1 + rnd.nextInt(12);
            int[] px = new int[w * h];
            for (int j = 0; j < px.length; j++) px[j] = palette[rnd.nextInt(palette.length)];
            roundTrip(new FramePixels(w, h, px), "random#" + i);
        }
        roundTrip(new FramePixels(1, 1, new int[]{0xFFABCDEF}), "1x1");
        roundTrip(new FramePixels(9, 1, new int[]{1, 2, 2, 3, 0, 4, 4, 4, 5}.length == 9
                ? new int[]{0xFF000001, 0xFF000002, 0xFF000002, 0xFF000003, 0, 0xFF000004, 0xFF000004, 0xFF000004, 0xFF000005}
                : null), "single row");
        int[] cb = new int[8 * 8];
        for (int y = 0; y < 8; y++) for (int x = 0; x < 8; x++) cb[y * 8 + x] = ((x + y) % 2 == 0) ? 0xFFFFFFFF : 0xFF000000;
        FramePixels checker = new FramePixels(8, 8, cb);
        roundTrip(checker, "checkerboard");
        check(Mesher.mesh(checker).size() == 64, "checkerboard needs one rect per pixel");

        // 4. Upscale detection
        int k = 3;
        int[] big = new int[src.width * k * src.height * k];
        for (int y = 0; y < src.height * k; y++)
            for (int x = 0; x < src.width * k; x++) big[y * src.width * k + x] = src.get(x / k, y / k);
        FramePixels blown = new FramePixels(src.width * k, src.height * k, big);
        int det = FrameLoader.detectScale(blown);
        check(det == k, "detect 3x upscale, got " + det);
        check(Arrays.equals(FrameLoader.downsample(blown, det).copyRaw(), src.copyRaw()), "downsample restores the asset");
        check(FrameLoader.detectScale(new FramePixels(4, 4, new int[16])) == 1, "blank image is not collapsed");

        // 5. Pre-sized frame set
        if (args.length > 1) frameSetChecks(Path.of(args[1]));
        syntheticSetChecks();

        System.out.println((failures == 0 ? "ALL PASSED" : failures + " FAILED") + " (" + checks + " checks)");
        System.exit(failures == 0 ? 0 : 1);
    }

    static void frameSetChecks(Path dir) throws Exception {
        FrameSet set = FrameSet.load(dir);
        check(set.size() == 10, "10 frames loaded, got " + set.size());
        check(set.minLines() == 6 && set.maxLines() == 15, "lines 6..15");
        check(set.width() == 10, "width 10");
        check(set.warnings().isEmpty(), "no warnings, got " + set.warnings());
        int[] expectedRects = {160, 172, 183, 189, 197, 204, 206, 221, 208, 212};
        int i = 0;
        for (FrameSet.Entry e : set.entries()) {
            check(e.pixels().height == 9 * e.lines() + 10, "height rule for " + e.lines());
            check(Arrays.equals(Mesher.raster(e.rects(), e.pixels().width, e.pixels().height), e.pixels().copyRaw()),
                    "round trip frame " + e.lines());
            check(e.rects().size() == expectedRects[i], "rect count frame " + e.lines() + ": " + e.rects().size());
            i++;
        }
        check(set.maxRects() == 221, "max rects 221, got " + set.maxRects());
        check(!set.select(10).clamped() && set.select(10).entry().lines() == 10, "exact select 10");
        check(set.select(5).clamped() && set.select(5).entry().lines() == 6, "5 clamps to 6");
        check(set.select(16).clamped() && set.select(16).entry().lines() == 15, "16 clamps to 15");
        check(set.select(0).entry().lines() == 6, "0 clamps to 6");
    }

    static void syntheticSetChecks() throws Exception {
        Path tmp = Files.createTempDirectory("framefit-test");
        try {
            write(tmp.resolve("sb_frame_6.png"), 4, 64);
            write(tmp.resolve("sb_frame_8.png"), 4, 82);
            write(tmp.resolve("sb_frame_x.png"), 4, 10);       // ignored by the glob
            FrameSet set = FrameSet.load(tmp);
            check(set.size() == 2, "synthetic set has 2 frames");
            check(set.select(7).entry().lines() == 8 && set.select(7).clamped(), "tie 7 picks the larger frame 8");
            check(set.select(6).entry().lines() == 6 && !set.select(6).clamped(), "synthetic exact 6");
            // mismatched width must be rejected
            write(tmp.resolve("sb_frame_9.png"), 5, 91);
            boolean rejected = false;
            try { FrameSet.load(tmp); } catch (java.io.IOException e) { rejected = true; }
            check(rejected, "mixed widths rejected");
            // non-PNG content with a .png name must be rejected
            Files.delete(tmp.resolve("sb_frame_9.png"));
            Files.write(tmp.resolve("sb_frame_10.png"), new byte[]{(byte) 0xFF, (byte) 0xD8, (byte) 0xFF, (byte) 0xE0, 0, 0, 0, 0, 0});
            boolean jpegRejected = false;
            try { FrameSet.load(tmp); } catch (java.io.IOException e) { jpegRejected = true; }
            check(jpegRejected, "JPEG disguised as PNG rejected");
        } finally {
            try (var st = Files.list(tmp)) { for (Path f : (Iterable<Path>) st::iterator) Files.deleteIfExists(f); }
            Files.deleteIfExists(tmp);
        }
    }

    static void write(Path f, int w, int h) throws Exception {
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) img.setRGB(x, y, ((x * 7 + y * 3) % 5 == 0) ? 0 : 0xFF000000 | (x * 40) << 8 | (y % 256));
        ImageIO.write(img, "png", f.toFile());
    }
}
