package dev.framefit;

import dev.framefit.frame.FrameSet;
import dev.framefit.frame.ThreeSlice;
import dev.framefit.spike.SpikeS1;
import org.bukkit.plugin.java.JavaPlugin;

public final class FrameFitPlugin extends JavaPlugin {
    private volatile ThreeSlice slice;
    private volatile FrameSet frames;

    @Override
    public void onEnable() {
        getDataFolder().mkdirs();
        getServer().getCommandMap().register("framefit", new FrameFitCommand(this));
        SpikeS1.clear(this); // sweep spike leftovers from a previous run or crash
    }

    @Override
    public void onDisable() {
        SpikeS1.clear(this);
    }

    public ThreeSlice slice() { return slice; }
    public void setSlice(ThreeSlice slice) { this.slice = slice; }
    public FrameSet frames() { return frames; }
    public void setFrames(FrameSet frames) { this.frames = frames; }
}
