package dev.framefit.frame;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Immutable ARGB pixel grid. Fully transparent pixels are normalised to 0 (they never become entities). */
public final class FramePixels {
    public final int width;
    public final int height;
    private final int[] argb;

    public FramePixels(int width, int height, int[] argb) {
        if (width <= 0 || height <= 0) throw new IllegalArgumentException("empty image");
        if (argb.length != width * height) throw new IllegalArgumentException("bad pixel array length");
        this.width = width;
        this.height = height;
        this.argb = argb.clone();
        for (int i = 0; i < this.argb.length; i++) {
            if ((this.argb[i] >>> 24) == 0) this.argb[i] = 0;
        }
    }

    public int get(int x, int y) { return argb[y * width + x]; }

    public boolean rowsEqual(int a, int b) {
        return Arrays.equals(argb, a * width, (a + 1) * width, argb, b * width, (b + 1) * width);
    }

    public int[] copyRaw() { return argb.clone(); }

    /** Number of distinct opaque/translucent colours (transparent excluded). */
    public int paletteSize() {
        Set<Integer> s = new HashSet<>();
        for (int v : argb) if ((v >>> 24) != 0) s.add(v);
        return s.size();
    }

    public boolean hasPartialAlpha() {
        for (int v : argb) {
            int a = v >>> 24;
            if (a != 0 && a != 255) return true;
        }
        return false;
    }
}
