package dev.framefit.frame;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Greedy meshing: per-colour row runs, merged vertically when identical. Output rectangles are strictly disjoint. */
public final class Mesher {
    private Mesher() {}

    private record Run(int x1, int x2, int argb) {}

    public static List<Rect> mesh(FramePixels p) {
        Map<Run, Integer> open = new HashMap<>();
        List<Rect> out = new ArrayList<>();
        for (int y = 0; y <= p.height; y++) {
            List<Run> cur = new ArrayList<>();
            if (y < p.height) {
                int x = 0;
                while (x < p.width) {
                    int c = p.get(x, y);
                    if ((c >>> 24) == 0) { x++; continue; }
                    int x2 = x;
                    while (x2 + 1 < p.width && p.get(x2 + 1, y) == c) x2++;
                    cur.add(new Run(x, x2, c));
                    x = x2 + 1;
                }
            }
            // close runs that do not continue on this row
            for (Run r : new ArrayList<>(open.keySet())) {
                if (!cur.contains(r)) {
                    int y0 = open.remove(r);
                    out.add(new Rect(r.x1(), y0, r.x2() - r.x1() + 1, y - y0, r.argb()));
                }
            }
            for (Run r : cur) open.putIfAbsent(r, y);
        }
        out.sort(Comparator.comparingInt(Rect::y).thenComparingInt(Rect::x));
        return out;
    }

    /** Rasterise rectangles back to ARGB (used by the round-trip tests). */
    public static int[] raster(List<Rect> rects, int w, int h) {
        int[] px = new int[w * h];
        for (Rect r : rects) {
            for (int yy = r.y(); yy < r.y() + r.h(); yy++) {
                for (int xx = r.x(); xx < r.x() + r.w(); xx++) {
                    if (px[yy * w + xx] != 0) throw new IllegalStateException("overlapping rectangles");
                    px[yy * w + xx] = r.argb();
                }
            }
        }
        return px;
    }
}
