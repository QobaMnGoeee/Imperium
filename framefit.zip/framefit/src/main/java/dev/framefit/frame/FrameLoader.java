package dev.framefit.frame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Loads a lossless PNG, rejects anything else, and undoes integer nearest-neighbour upscaling. */
public final class FrameLoader {
    private FrameLoader() {}

    public record Loaded(FramePixels pixels, int inferredScale) {}

    private static final byte[] PNG_MAGIC = {(byte) 0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A};

    public static Loaded load(Path file) throws IOException {
        byte[] data = Files.readAllBytes(file);
        if (data.length < 8) throw new IOException("file too small to be a PNG");
        for (int i = 0; i < 8; i++) {
            if (data[i] != PNG_MAGIC[i]) throw new IOException("not a PNG (JPEG and other lossy formats are rejected)");
        }
        BufferedImage img = ImageIO.read(new ByteArrayInputStream(data));
        if (img == null) throw new IOException("PNG could not be decoded");
        int w = img.getWidth(), h = img.getHeight();
        FramePixels full = new FramePixels(w, h, img.getRGB(0, 0, w, h, null, 0, w));
        int k = detectScale(full);
        return new Loaded(k > 1 ? downsample(full, k) : full, k);
    }

    /** Largest k such that every colour run (rows and columns) is divisible by k and the image is a k-times blow-up. */
    public static int detectScale(FramePixels p) {
        if (isUniform(p)) return 1;   // a single-colour image has no detectable grid
        int g = 0;
        for (int y = 0; y < p.height; y++) {
            int run = 1;
            for (int x = 1; x <= p.width; x++) {
                if (x < p.width && p.get(x, y) == p.get(x - 1, y)) run++;
                else { g = gcd(g, run); run = 1; }
            }
        }
        for (int x = 0; x < p.width; x++) {
            int run = 1;
            for (int y = 1; y <= p.height; y++) {
                if (y < p.height && p.get(x, y) == p.get(x, y - 1)) run++;
                else { g = gcd(g, run); run = 1; }
            }
        }
        for (int k = g; k > 1; k--) {
            if (p.width % k != 0 || p.height % k != 0) continue;
            if ((long) (p.width / k) * (p.height / k) < 2) continue;   // refuse to collapse to a single pixel
            if (isBlowUp(p, k)) return k;
        }
        return 1;
    }

    private static boolean isUniform(FramePixels p) {
        int first = p.get(0, 0);
        for (int y = 0; y < p.height; y++)
            for (int x = 0; x < p.width; x++)
                if (p.get(x, y) != first) return false;
        return true;
    }

    private static boolean isBlowUp(FramePixels p, int k) {
        for (int y = 0; y < p.height; y++)
            for (int x = 0; x < p.width; x++)
                if (p.get(x, y) != p.get(x - x % k, y - y % k)) return false;
        return true;
    }

    public static FramePixels downsample(FramePixels p, int k) {
        int w = p.width / k, h = p.height / k;
        int[] out = new int[w * h];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                out[y * w + x] = p.get(x * k, y * k);
        return new FramePixels(w, h, out);
    }

    private static int gcd(int a, int b) { return b == 0 ? a : gcd(b, a % b); }
}
