package dev.framefit.frame;

/** Axis-aligned rectangle in art pixels, single opaque or translucent colour (0xAARRGGBB). */
public record Rect(int x, int y, int w, int h, int argb) {}
