package dev.framefit.frame;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Vertical 3-slice: top cap / stretch band / bottom cap.
 * The stretch band is the largest run of identical rows that lies strictly inside the image.
 * Stretching repeats that one row. No interpolation, caps are never touched.
 */
public final class ThreeSlice {
    public final FramePixels source;
    public final int stretchStart;        // first stretch row (inclusive)
    public final int stretchEnd;          // last stretch row + 1 (exclusive)
    private final Map<Integer, List<Rect>> meshCache = new ConcurrentHashMap<>();

    private ThreeSlice(FramePixels source, int start, int end) {
        this.source = source;
        this.stretchStart = start;
        this.stretchEnd = end;
    }

    public static ThreeSlice detect(FramePixels src) {
        int bestStart = -1, bestLen = 0;
        double bestDist = Double.MAX_VALUE;
        int y = 0;
        while (y < src.height) {
            int e = y + 1;
            while (e < src.height && src.rowsEqual(y, e)) e++;
            boolean interior = y > 0 && e < src.height;
            if (interior) {
                int len = e - y;
                double dist = Math.abs((y + e) / 2.0 - src.height / 2.0);
                if (len > bestLen || (len == bestLen && dist < bestDist)) {
                    bestStart = y; bestLen = len; bestDist = dist;
                }
            }
            y = e;
        }
        if (bestStart < 0) throw new IllegalArgumentException("no interior run of identical rows: asset is not stretchable");
        return new ThreeSlice(src, bestStart, bestStart + bestLen);
    }

    public int topHeight() { return stretchStart; }
    public int bottomHeight() { return source.height - stretchEnd; }
    /** Shortest frame that keeps both caps intact and one stretch row. */
    public int minHeight() { return topHeight() + 1 + bottomHeight(); }

    /** Target height clamped to the minimum (caps are never cut). */
    public int effectiveHeight(int target) { return Math.max(target, minHeight()); }

    public FramePixels resize(int targetHeight) {
        int th = effectiveHeight(targetHeight);
        int w = source.width;
        int[] raw = source.copyRaw();
        int[] out = new int[w * th];
        int bottom = bottomHeight();
        for (int y = 0; y < th; y++) {
            int sy;
            if (y < topHeight()) sy = y;
            else if (y >= th - bottom) sy = source.height - (th - y);
            else sy = stretchStart;                      // the representative stretch row
            System.arraycopy(raw, sy * w, out, y * w, w);
        }
        return new FramePixels(w, th, out);
    }

    /** Meshed rectangles for a target height (cached). */
    public List<Rect> meshFor(int targetHeight) {
        return meshCache.computeIfAbsent(effectiveHeight(targetHeight), h -> Mesher.mesh(resize(h)));
    }
}
