package dev.framefit.frame;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.NavigableMap;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pre-sized frames, one PNG per scoreboard line count: sb_frame_&lt;lines&gt;.png.
 * Nothing is stretched or resampled; the frame for N lines is used exactly as drawn.
 */
public final class FrameSet {
    private static final Pattern NAME = Pattern.compile("sb_frame_(\\d+)\\.png");
    /** Observed rule in the supplied art: height = 9 * lines + 10. Only used to warn, never to rewrite. */
    private static final int ROW_PX = 9, PADDING_PX = 10;

    public record Entry(int lines, FramePixels pixels, List<Rect> rects) {}
    public record Selection(Entry entry, boolean clamped) {}

    private final NavigableMap<Integer, Entry> byLines;
    private final List<String> warnings;

    private FrameSet(NavigableMap<Integer, Entry> byLines, List<String> warnings) {
        this.byLines = byLines;
        this.warnings = List.copyOf(warnings);
    }

    public static FrameSet load(Path dir) throws IOException {
        NavigableMap<Integer, Entry> map = new TreeMap<>();
        List<String> warnings = new ArrayList<>();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, "sb_frame_*.png")) {
            for (Path f : ds) {
                Matcher m = NAME.matcher(f.getFileName().toString());
                if (!m.matches()) { warnings.add("ignored " + f.getFileName() + " (name must be sb_frame_<lines>.png)"); continue; }
                int lines;
                try { lines = Integer.parseInt(m.group(1)); }
                catch (NumberFormatException e) { warnings.add("ignored " + f.getFileName() + " (line count out of range)"); continue; }
                if (lines < 1) { warnings.add("ignored " + f.getFileName() + " (line count must be >= 1)"); continue; }
                FrameLoader.Loaded loaded = FrameLoader.load(f);
                if (loaded.inferredScale() > 1)
                    warnings.add(f.getFileName() + ": undid " + loaded.inferredScale() + "x upscale");
                if (loaded.pixels().hasPartialAlpha())
                    warnings.add(f.getFileName() + ": partial alpha present (translucent quads composite in an uncontrolled order)");
                int expected = ROW_PX * lines + PADDING_PX;
                if (loaded.pixels().height != expected)
                    warnings.add(f.getFileName() + ": height " + loaded.pixels().height + " differs from 9*lines+10 = " + expected);
                map.put(lines, new Entry(lines, loaded.pixels(), List.copyOf(Mesher.mesh(loaded.pixels()))));
            }
        }
        if (map.isEmpty()) throw new IOException("no sb_frame_<lines>.png files found in " + dir);
        int w = map.firstEntry().getValue().pixels().width;
        for (Entry e : map.values())
            if (e.pixels().width != w)
                throw new IOException("all frames must share one width; sb_frame_" + e.lines() + ".png is "
                        + e.pixels().width + " px wide, expected " + w);
        return new FrameSet(map, warnings);
    }

    /** Exact frame if present, otherwise the nearest available line count (a tie picks the larger frame). */
    public Selection select(int lines) {
        Entry exact = byLines.get(lines);
        if (exact != null) return new Selection(exact, false);
        var lo = byLines.floorEntry(lines);
        var hi = byLines.ceilingEntry(lines);
        Entry pick;
        if (lo == null) pick = hi.getValue();
        else if (hi == null) pick = lo.getValue();
        else pick = (lines - lo.getKey() < hi.getKey() - lines) ? lo.getValue() : hi.getValue();
        return new Selection(pick, true);
    }

    public int minLines() { return byLines.firstKey(); }
    public int maxLines() { return byLines.lastKey(); }
    public int width() { return byLines.firstEntry().getValue().pixels().width; }
    public int size() { return byLines.size(); }
    public List<String> warnings() { return warnings; }

    public int maxRects() {
        int m = 0;
        for (Entry e : byLines.values()) m = Math.max(m, e.rects().size());
        return m;
    }
    public Iterable<Entry> entries() { return byLines.values(); }
}
