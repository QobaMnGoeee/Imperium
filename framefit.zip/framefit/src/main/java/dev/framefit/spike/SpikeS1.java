package dev.framefit.spike;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

/**
 * S1: exact geometry of a Text Display background quad.
 * Builds four probes side by side, each next to a 1-block reference grid, so the quad can be measured in blocks
 * (1 block = 40 font px if the 1/40 assumption holds; that is what this spike verifies).
 */
public final class SpikeS1 {
    private SpikeS1() {}

    private static NamespacedKey key(Plugin p) { return new NamespacedKey(p, "spike"); }

    public static void run(Plugin plugin, Player player) {
        clear(plugin);
        // Snap the view direction to a cardinal axis so the displays face the player squarely.
        float yaw = Math.round(player.getLocation().getYaw() / 90f) * 90f;
        double rad = Math.toRadians(yaw);
        // Minecraft: forward = (-sin(yaw), 0, cos(yaw)); right = (-cos(yaw), 0, -sin(yaw)).
        int fx = (int) Math.round(-Math.sin(rad)), fz = (int) Math.round(Math.cos(rad));
        int rx = (int) Math.round(-Math.cos(rad)), rz = (int) Math.round(-Math.sin(rad));
        Location p = player.getLocation();
        double ax = Math.floor(p.getX()) + 0.5 + fx * 8;
        double ay = Math.floor(p.getY());
        double az = Math.floor(p.getZ()) + 0.5 + fz * 8;
        float displayYaw = yaw + 180f; // a display at yaw 0 faces south; it must face back toward the player

        Component[] texts = { Component.text(" "), Component.text(" \n "), Component.text(" "), Component.empty() };
        int[] lineWidth = { -1, -1, 120, -1 };
        for (int k = 0; k < texts.length; k++) {
            Location at = new Location(player.getWorld(), ax + rx * k * 9, ay, az + rz * k * 9, displayYaw, 0f);
            grid(plugin, player, at);
            text(plugin, player, at, texts[k], lineWidth[k]);
        }

        player.sendMessage(Component.text("S1 spawned 4 probes (left to right as you face them):", NamedTextColor.GREEN));
        player.sendMessage(Component.text(" 1) text \" \"   2) text \" \\n \"   3) text \" \" with lineWidth 120   4) empty component", NamedTextColor.GRAY));
        player.sendMessage(Component.text("Press F1 (hide HUD), stand still facing them, take ONE straight-on screenshot per probe. "
                + "Red = Text Display background. Grid cells = 1 block. Then /framefit spike clear.", NamedTextColor.YELLOW));
    }

    private static void grid(Plugin plugin, Player viewer, Location at) {
        World w = at.getWorld();
        for (int i = -3; i <= 3; i++) {
            for (int j = 0; j < 4; j++) {
                final int ci = i, cj = j;
                BlockDisplay d = w.spawn(at, BlockDisplay.class, e -> {
                    e.setBlock(((ci + cj) % 2 == 0 ? Material.WHITE_CONCRETE : Material.GRAY_CONCRETE).createBlockData());
                    e.setTransformation(new Transformation(new Vector3f(ci - 0.5f, cj, 0f), new AxisAngle4f(),
                            new Vector3f(1f, 1f, 0.02f), new AxisAngle4f()));
                    prepare(plugin, viewer, e);
                });
                show(plugin, viewer, d);
            }
        }
    }

    private static void text(Plugin plugin, Player viewer, Location at, Component text, int lineWidth) {
        TextDisplay d = at.getWorld().spawn(at, TextDisplay.class, e -> {
            e.text(text);
            e.setDefaultBackground(false);
            e.setBackgroundColor(Color.fromARGB(255, 255, 0, 0));
            e.setBrightness(new Display.Brightness(15, 15));
            e.setShadowed(false);
            e.setSeeThrough(false);
            e.setBillboard(Display.Billboard.FIXED);
            if (lineWidth > 0) e.setLineWidth(lineWidth);
            // 0.05 in front of the reference grid so the two never z-fight.
            e.setTransformation(new Transformation(new Vector3f(0f, 0f, 0.05f), new AxisAngle4f(),
                    new Vector3f(1f, 1f, 1f), new AxisAngle4f()));
            prepare(plugin, viewer, e);
        });
        show(plugin, viewer, d);
    }

    private static void prepare(Plugin plugin, Player viewer, Display e) {
        e.setPersistent(false);
        e.setVisibleByDefault(false);
        e.setViewRange(8f);
        e.getPersistentDataContainer().set(key(plugin), PersistentDataType.BYTE, (byte) 1);
    }

    private static void show(Plugin plugin, Player viewer, Display e) { viewer.showEntity(plugin, e); }

    /** Removes every spike entity tagged by this plugin in all worlds. Returns how many were removed. */
    public static int clear(Plugin plugin) {
        int n = 0;
        for (World w : plugin.getServer().getWorlds()) {
            for (Display d : w.getEntitiesByClass(Display.class)) {
                if (d.getPersistentDataContainer().has(key(plugin), PersistentDataType.BYTE)) { d.remove(); n++; }
            }
        }
        return n;
    }
}
