package dev.framefit;

import dev.framefit.frame.FrameLoader;
import dev.framefit.frame.FrameSet;
import dev.framefit.frame.ThreeSlice;
import dev.framefit.spike.SpikeS1;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

/** /framefit loadset <folder> | load <file.png> | spike s1 | spike clear. Registered through the command map (paper-plugin.yml has no commands section). */
public final class FrameFitCommand extends Command {
    private final FrameFitPlugin plugin;

    public FrameFitCommand(FrameFitPlugin plugin) {
        super("framefit");
        this.plugin = plugin;
        setDescription("FrameFit admin command");
        setUsage("/framefit loadset <folder> | load <file.png> | spike <s1|clear>");
        setPermission("framefit.admin");
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!testPermission(sender)) return true;
        if (args.length == 0) { msg(sender, getUsage(), NamedTextColor.GRAY); return true; }

        switch (args[0].toLowerCase()) {
            case "loadset" -> {
                if (args.length < 2) { msg(sender, "Usage: /framefit loadset <folder> (folder inside the plugin folder, files sb_frame_<lines>.png)", NamedTextColor.RED); return true; }
                loadSet(sender, args[1]);
            }
            case "load" -> {
                if (args.length < 2) { msg(sender, "Usage: /framefit load <file.png> (file inside the plugin folder)", NamedTextColor.RED); return true; }
                load(sender, args[1]);
            }
            case "spike" -> {
                if (!(sender instanceof Player player)) { msg(sender, "Spikes must be run by a player.", NamedTextColor.RED); return true; }
                String id = args.length > 1 ? args[1].toLowerCase() : "";
                switch (id) {
                    case "s1" -> SpikeS1.run(plugin, player);
                    case "clear" -> { int n = SpikeS1.clear(plugin); msg(sender, "Removed " + n + " spike entities.", NamedTextColor.GREEN); }
                    default -> msg(sender, "Available now: s1, clear. S2-S7 depend on the S1 numbers (see docs/spike-results.md).", NamedTextColor.YELLOW);
                }
            }
            default -> msg(sender, getUsage(), NamedTextColor.GRAY);
        }
        return true;
    }

    private void loadSet(CommandSender sender, String name) {
        Path base = plugin.getDataFolder().toPath().toAbsolutePath().normalize();
        Path dir = base.resolve(name).normalize();
        if (!dir.startsWith(base)) { msg(sender, "Folder must be inside the plugin folder.", NamedTextColor.RED); return; }
        try {
            FrameSet set = FrameSet.load(dir);
            plugin.setFrames(set);
            msg(sender, "Loaded " + set.size() + " frames (lines " + set.minLines() + ".." + set.maxLines() + "), "
                    + set.width() + " px wide, at most " + set.maxRects() + " entities per viewer.", NamedTextColor.GREEN);
            for (String w : set.warnings()) msg(sender, "Warning: " + w, NamedTextColor.YELLOW);
        } catch (IOException | IllegalArgumentException e) {
            msg(sender, "Cannot load frame set: " + e.getMessage(), NamedTextColor.RED);
        }
    }

    private void load(CommandSender sender, String name) {
        Path base = plugin.getDataFolder().toPath().toAbsolutePath().normalize();
        Path file = base.resolve(name).normalize();
        if (!file.startsWith(base)) { msg(sender, "File must be inside the plugin folder.", NamedTextColor.RED); return; }
        try {
            FrameLoader.Loaded loaded = FrameLoader.load(file);
            ThreeSlice slice = ThreeSlice.detect(loaded.pixels());
            plugin.setSlice(slice);
            msg(sender, "Loaded " + name + ": " + loaded.pixels().width + "x" + loaded.pixels().height
                    + " px, " + loaded.pixels().paletteSize() + " colours"
                    + (loaded.inferredScale() > 1 ? ", undid " + loaded.inferredScale() + "x upscale" : "")
                    + ". Stretch rows " + slice.stretchStart + ".." + (slice.stretchEnd - 1)
                    + ", min height " + slice.minHeight() + " px, "
                    + slice.meshFor(slice.minHeight()).size() + " entities.", NamedTextColor.GREEN);
            if (loaded.pixels().hasPartialAlpha())
                msg(sender, "Warning: partial alpha present; translucent quads composite in an order we cannot control.", NamedTextColor.YELLOW);
        } catch (IOException | IllegalArgumentException e) {
            msg(sender, "Cannot load frame: " + e.getMessage(), NamedTextColor.RED);
        }
    }

    @Override
    public List<String> tabComplete(CommandSender sender, String alias, String[] args) {
        if (args.length == 1) return List.of("loadset", "load", "spike");
        if (args.length == 2 && args[0].equalsIgnoreCase("spike")) return List.of("s1", "clear");
        return List.of();
    }

    private static void msg(CommandSender to, String text, NamedTextColor color) {
        to.sendMessage(Component.text(text, color));
    }
}
