# Phase 0 spike results

No constant in the plugin may be guessed. Every value below is measured in a real 1.21.11 client
and entered here by a human. Until a row is filled, nothing downstream may depend on it.

## S1: Text Display background quad geometry

Run `/framefit spike s1`, press F1, take one straight-on screenshot per probe.
Grid cells are exactly 1 block. Red is the Text Display background.

| Probe | Text | Quad width (blocks) | Quad height (blocks) | Left edge vs anchor (blocks) | Bottom edge vs anchor (blocks) | Draws at all? |
|---|---|---|---|---|---|---|
| 1 | `" "` | _TBD_ | _TBD_ | _TBD_ | _TBD_ | _TBD_ |
| 2 | `" \n "` | _TBD_ | _TBD_ | _TBD_ | _TBD_ | _TBD_ |
| 3 | `" "` + lineWidth 120 | _TBD_ | _TBD_ | _TBD_ | _TBD_ | _TBD_ |
| 4 | empty component | _TBD_ | _TBD_ | _TBD_ | _TBD_ | _TBD_ |

Derived (fill after measuring): `Qw = width_blocks * 40`, `Qh = height_blocks * 40` font px.
The skill's working assumption (a single-space line is about 4 px wide, 8-9 px tall, quad grows by 1 px
of padding per side) is a hypothesis to confirm or reject, not a fact.

## S2 to S7

S2 (seams between adjacent rectangles) needs the S1 quad size to place its test grid, so it is not
implemented yet. S3 to S7 follow once S1 and S2 are recorded.
