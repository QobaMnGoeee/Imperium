# FrameFit

Paper 1.21.11 plugin (Java 21): a pixel-art frame built from vanilla Text Displays that fits the
real size of a player's sidebar scoreboard. No resource pack, no client mod.

Scope for this repo: **left edge only**, nothing mirrored or rotated.

Primary art: ten pre-sized frames in `samples/frames/` (`sb_frame_6.png` .. `sb_frame_15.png`, 10 px wide,
height = 9 x lines + 10). The plugin picks the file for the sidebar's line count and uses it exactly as drawn.
The older single 30x142 asset (`samples/stretch-test/`) is kept only as a test fixture for the 3-slice stretcher.

## Status

| Part | State |
|---|---|
| PNG loader, upscale detection, greedy mesher, FrameSet (size selection), 3-slice fallback | Done, compiled, 310 self-test checks pass |
| Plugin skeleton, `/framefit load`, spike S1 | Written, **not compiled** (Paper API was unreachable in the authoring sandbox) |
| Spikes S2 to S7, sidebar size maths, projection, lifecycle | Not started; blocked on measured S1 values |

## Asset facts (measured, not assumed)

| Lines | Size (px) | Rectangles |
|---|---|---|
| 6 | 10x64 | 160 |
| 7 | 10x73 | 172 |
| 8 | 10x82 | 183 |
| 9 | 10x91 | 189 |
| 10 | 10x100 | 197 |
| 11 | 10x109 | 204 |
| 12 | 10x118 | 206 |
| 13 | 10x127 | 221 |
| 14 | 10x136 | 208 |
| 15 | 10x145 | 212 |

- All ten are lossless RGBA PNGs, no partial alpha, 107 to 168 colours each (gradients and highlights).
- Entity count is about 160 to 221 **per viewer**, above the guide's default soft cap of 96. Column-first meshing
  saves only one rectangle per frame, so the count is a property of the art.
- Line counts outside 6..15 use the nearest available frame (flagged as clamped).

## Run the self test (no Paper needed)

    ./gradlew selfTest
    # or, with only a JDK:
    javac -d out $(find src/main/java/dev/framefit/frame src/test -name '*.java')
    java -cp out dev.framefit.SelfTest samples/oneparttextbox.png

## In game

    /framefit loadset frames             (copy samples/frames/ into plugins/FrameFit/frames/ first)
    /framefit spike s1                   then follow docs/spike-results.md
    /framefit spike clear
