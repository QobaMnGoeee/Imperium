plugins { java }

group = "dev.framefit"
version = "0.1.0"

java { toolchain { languageVersion = JavaLanguageVersion.of(21) } }

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
}

tasks.processResources {
    filesMatching("paper-plugin.yml") { expand("version" to project.version) }
}

// Dependency-free self test for the pure geometry classes (no JUnit needed).
tasks.register<JavaExec>("selfTest") {
    dependsOn("testClasses")
    classpath = sourceSets["test"].runtimeClasspath
    mainClass = "dev.framefit.SelfTest"
    args(file("samples/stretch-test/oneparttextbox.png").absolutePath, file("samples/frames").absolutePath)
}
